import logging
from pathlib import Path
from typing import Dict, List

from lhotse import CutSet, load_manifest_lazy

class MultiDataset:
    def __init__(self, args):
        self.fbank_dir = Path(args.manifest_dir)
        self.prefixes = args.multidataset_prefix_list.split(",")

    def _load_cuts(self, split: str) -> List[CutSet]:
        cuts = []
        for prefix in self.prefixes:
            # filename = f"eng16_cuts_{split}.jsonl.gz"
            filename = f"{prefix}_cuts_{split}.jsonl.gz"
            path = self.fbank_dir / prefix / filename
            logging.info(f"Loading {path} in lazy mode")
            cuts.append(load_manifest_lazy(path))
        return cuts

    def train_cuts(self) -> CutSet:
        logging.info("Loading train cuts")
        cuts = self._load_cuts("train_shuf")
        return CutSet.mux(*cuts, weights=[len(c) for c in cuts])

    def valid_cuts(self) -> CutSet:
        logging.info("Loading valid cuts")
        cuts = self._load_cuts("valid")
        return CutSet.mux(*cuts, weights=[len(c) for c in cuts])

    def test_cuts(self) -> Dict[str, CutSet]:
        logging.info("Loading test cuts")
        cuts_dict = {}
        for prefix in self.prefixes:
            # filename = f"{prefix}_cuts_test.jsonl.gz"
            filename = f"eng16_cuts_test.jsonl.gz"
            path = self.fbank_dir / prefix / filename
            logging.info(f"Loading {path} in lazy mode")
            cuts_dict[f"{prefix}_cuts"] = load_manifest_lazy(path)
        return cuts_dict