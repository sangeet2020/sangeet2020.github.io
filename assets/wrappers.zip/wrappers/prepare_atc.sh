#!/usr/bin/env bash

set -eou pipefail

# Default parameters
nj=24
stage=-1
stop_stage=100
num_splits=20  # Split dataset to avoid OOM during feature extraction
dataset=all_data
lang=en
PREFIX=atc	# IMPORTANT parameter. eg. eng16, deu16, ru...

# Directory paths
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs
DATA_DIR=/mnt/amtmpvf2/sangeet/data
OUTPUT_DIR=${ROOT}/UkOSTT/ASR/data/${PREFIX}/${dataset}
MUSAN_MANIFESTS_DIR=${ROOT}/UkOSTT/ASR/data/musan
MANIFEST_DIR=${OUTPUT_DIR}/manifests
FBANK_DIR=${OUTPUT_DIR}/fbank
LANG_BPE=${OUTPUT_DIR}/lang_bpe
LM_DIR=${OUTPUT_DIR}/lm
LOCAL_PATH=${ROOT}/UkOSTT/ASR/local

# Logs
LOGS_DIR=${OUTPUT_DIR}/logs
mkdir -p ${LOGS_DIR}
LOG_FILE="${LOGS_DIR}/prepare_data_$(date +%Y%m%d_%H%M%S).log"

exec &> >(tee -a "${LOG_FILE}")

echo "Script started at $(date)"
echo "Logging to ${LOG_FILE}"


. ../shared/parse_options.sh || exit 1

# Vocab sizes for sentence piece models
# Will generate ${OUTPUT_DIR}/lang_bpe_xxx for each size
vocab_sizes=(500)

# Create output directory
mkdir -p ${OUTPUT_DIR}

# Logging function (from espnet)
log() {
    local fname=${BASH_SOURCE[1]##*/}
    echo -e "\n$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $* ********"
}

# Check for ffmpeg requirement
if ! command -v ffmpeg &> /dev/null; then
    echo "This dataset requires ffmpeg"
    echo "Please install ffmpeg first"
    echo ""
    echo "  sudo apt-get install ffmpeg"
    exit 1
fi

# Stage 0: Download Musan data
if [ $stage -le 0 ] && [ $stop_stage -ge 0 ]; then
    log "Stage 0: Download Musan data"
    log "No need, using old download at /mnt/local/sangeet/data/Deu16/musan"
fi

# Stage 1: Prepare manifests
if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
    log "Stage 1: Prepare ${PREFIX} manifests"
    mkdir -p ${MANIFEST_DIR}
    if [ ! -e ${MANIFEST_DIR}/.${PREFIX}.done ]; then
        lhotse prepare eng16 -j 16 -prefix atcosim ${DATA_DIR}/ATCOSIM ${MANIFEST_DIR}
        lhotse prepare eng16 -j 16 -prefix ldc ${DATA_DIR}/LDC94S14A ${MANIFEST_DIR}
        lhotse prepare eng16 -j 16 -prefix fra_airport ${DATA_DIR}/FRA_airport/8kHz ${MANIFEST_DIR}
        
        # Merge manifests from LDC, ATCO, FRA
        for split in train test valid; do
            for type in supervisions recordings; do
                pieces=$(find "${MANIFEST_DIR}/" -name "*_${type}_${split}.jsonl.gz")
                lhotse combine $pieces "${MANIFEST_DIR}/${PREFIX}_${type}_${split}.jsonl.gz"
            done
        done

        touch ${MANIFEST_DIR}/.${PREFIX}.done
    fi
fi

# Stage 2: Prepare musan manifest
if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
    log "Stage 2: Prepare musan manifest"
    mkdir -p ${MANIFEST_DIR}
    if [ ! -e ${MANIFEST_DIR}/.musan.done ]; then
        ln -svf $(realpath ${MUSAN_MANIFESTS_DIR}/manifests/musan_*) \
            ${MANIFEST_DIR}
        touch ${MANIFEST_DIR}/.musan.done
    fi
    # lhotse prepare musan /mnt/local/sangeet/data/Deu16/musan ${MUSAN_MANIFESTS_DIR}/manifests
fi

# Stage 3: Preprocess manifest
if [ $stage -le 3 ] && [ $stop_stage -ge 3 ]; then
    log "Stage 3: Preprocess ${PREFIX} manifest (data cleaning and normalizing)"
    if [ ! -e ${FBANK_DIR}/.preprocess_complete ]; then
        ${LOCAL_PATH}/preprocess_cuts.py \
            --prefix ${PREFIX} \
            --lang ${lang} \
            --src-dir ${MANIFEST_DIR} \
            --output-dir ${FBANK_DIR}
        touch ${FBANK_DIR}/.preprocess_complete
    fi
fi

# Stage 4: Compute fbank for dev and test
if [ $stage -le 4 ] && [ $stop_stage -ge 4 ]; then
    log "Stage 4: Compute fbank for dev and test subsets of ${PREFIX}"
    mkdir -p ${FBANK_DIR}
    if [ ! -e ${FBANK_DIR}/.${PREFIX}_dev_test.done ]; then
        ${LOCAL_PATH}/compute_fbank_dev_test.py \
            --prefix ${PREFIX} \
            --output-dir ${FBANK_DIR}
        touch ${FBANK_DIR}/.${PREFIX}_dev_test.done
    fi
fi

# Stage 5: Split train subset
if [ $stage -le 5 ] && [ $stop_stage -ge 5 ]; then
    log "Stage 5: Split train subset into ${num_splits} pieces"
    split_dir=${FBANK_DIR}/${PREFIX}_train_split_${num_splits}
    if [ ! -e $split_dir/.${PREFIX}_train_split.done ]; then
        lhotse split $num_splits -i 1 \
            ${FBANK_DIR}/${PREFIX}_cuts_train_raw.jsonl.gz \
            $split_dir
        touch $split_dir/.${PREFIX}_train_split.done
    fi
fi

# Stage 6: Compute fbank for train
if [ $stage -le 6 ] && [ $stop_stage -ge 6 ]; then
    log "Stage 6: Compute fbank train subset of ${PREFIX}"
    if [ ! -e ${FBANK_DIR}/.${PREFIX}_train.done ]; then
        ${LOCAL_PATH}/compute_fbank_train_splits.py \
            --prefix ${PREFIX} \
            --output-dir ${FBANK_DIR} \
            --num-workers $nj \
            --batch-duration 600 \
            --start 0 \
            --num-splits $num_splits
        touch ${FBANK_DIR}/.${PREFIX}_train.done
    fi
fi

# Stage 7: Combine features for train
if [ $stage -le 7 ] && [ $stop_stage -ge 7 ]; then
    log "Stage 7: Combine features for train"
    if [ ! -e ${FBANK_DIR}/${PREFIX}_cuts_train.jsonl.gz ]; then
        pieces=$(find ${FBANK_DIR}/${PREFIX}_train_split_${num_splits} \
            -name "${PREFIX}_cuts_train.*.jsonl.gz")
        lhotse combine $pieces ${FBANK_DIR}/${PREFIX}_cuts_train.jsonl.gz
    fi
    # Pre-shuffle the whole manifest 
    cat <(gunzip -c ${FBANK_DIR}/${PREFIX}_cuts_train.jsonl.gz) | \
        shuf | \
        gzip -c > ${FBANK_DIR}/${PREFIX}_cuts_train_shuf.jsonl.gz
fi

# Stage 8: Display manifest statistics
if [ $stage -le 8 ] && [ $stop_stage -ge 8 ]; then
    log "Stage 8: Display statistics"
    ${LOCAL_PATH}/display_manifest_statistics.py \
        --prefix ${PREFIX} \
        --output-dir ${FBANK_DIR}
fi

# Stage 9: Compute fbank for musan
if [ $stage -le 9 ] && [ $stop_stage -ge 9 ]; then
    log "Stage 9: Compute fbank for musan"
    mkdir -p ${FBANK_DIR}
    if [ ! -e ${FBANK_DIR}/.musan.done ]; then
        ln -svf $(realpath ${MUSAN_MANIFESTS_DIR}/fbank/musan_*) ${FBANK_DIR}
        touch ${FBANK_DIR}/.musan.done
    fi
    # ../local/compute_fbank_musan.py --src-dir ${MUSAN_MANIFESTS_DIR}/manifests --output-dir ${MUSAN_MANIFESTS_DIR}/fbank
fi

# Stage 10: Prepare Byte BPE based lang
if [ $stage -le 10 ] && [ $stop_stage -ge 10 ]; then
    log "Stage 10: Prepare Byte BPE based lang"
    
    for vocab_size in ${vocab_sizes[@]}; do
        LANG_DIR=${LANG_BPE}_${vocab_size}  
        mkdir -p ${LANG_DIR}

        if [ ! -f ${LANG_DIR}/transcript_words.txt ]; then
            log "Generate data for BPE training"
            
            # Dump transcripts for LM training
            file=$(find "${FBANK_DIR}/${PREFIX}_cuts_train_shuf.jsonl.gz")
            gunzip -c ${file} | \
                awk -F '"' '{print $30}' > ${LANG_DIR}/transcript_words.txt
            
            # Filter out duplicate sentences from SpeedPerturb
            awk '!a[$0]++' "${LANG_DIR}/transcript_words.txt" > temp.txt && \
                mv temp.txt "${LANG_DIR}/transcript_words.txt"

            # Ensure space only appears once
            sed -i 's/\t/ /g' ${LANG_DIR}/transcript_words.txt
            sed -i 's/[ ][ ]*/ /g' ${LANG_DIR}/transcript_words.txt
            
            sort -o ${LANG_DIR}/transcript_words.txt ${LANG_DIR}/transcript_words.txt
        fi

        if [ ! -f ${LANG_DIR}/words_no_ids.txt ]; then
            cat ${LANG_DIR}/transcript_words.txt | \
                sed 's/ /\n/g' | \
                sort -u | \
                sed '/^$/d' | \
                uniq > ${LANG_DIR}/words_no_ids.txt
        fi

        if [ ! -f ${LANG_DIR}/words.txt ]; then
            cat ${LANG_DIR}/transcript_words.txt | \
                sed 's/ /\n/g' | \
                sort -u | \
                sed '/^$/d' > ${LANG_DIR}/words.txt

            (echo '!SIL'; echo '<SPOKEN_NOISE>'; echo '<UNK>'; ) | \
                cat - ${LANG_DIR}/words.txt | \
                sort | \
                uniq | \
                awk '
                BEGIN {
                    print "<eps> 0";
                }
                {
                    if ($1 == "<s>") {
                        print "<s> is in the vocabulary!" | "cat 1>&2"
                        exit 1;
                    }
                    if ($1 == "</s>") {
                        print "</s> is in the vocabulary!" | "cat 1>&2"
                        exit 1;
                    }
                    printf("%s %d\n", $1, NR);
                }
                END {
                    printf("#0 %d\n", NR+1);
                    printf("<s> %d\n", NR+2);
                    printf("</s> %d\n", NR+3);
                }' > ${LANG_DIR}/words || exit 1
            mv ${LANG_DIR}/words ${LANG_DIR}/words.txt
        fi
        
        if [ ! -f ${LANG_DIR}/bpe.model ]; then
            python ${LOCAL_PATH}/train_bpe_model.py \
                --lang-dir ${LANG_DIR} \
                --vocab-size $vocab_size \
                --transcript ${LANG_DIR}/transcript_words.txt
        fi
    done
fi

# Stage 11: Prepare BPE based lexicon
if [ $stage -le 11 ] && [ $stop_stage -ge 11 ]; then
    log "Stage 11: Prepare BPE based lexicon"
    
    for vocab_size in ${vocab_sizes[@]}; do
        LANG_DIR=${LANG_BPE}_${vocab_size}  
        if [ ! -f ${LANG_DIR}/L_disambig.pt ]; then
            ${LOCAL_PATH}/prepare_lang_bpe.py --lang-dir ${LANG_DIR}
            
            log "Validating ${LANG_DIR}/lexicon.txt"
            ${LOCAL_PATH}/validate_bpe_lexicon.py \
                --lexicon ${LANG_DIR}/lexicon.txt \
                --bpe-model ${LANG_DIR}/bpe.model
        fi
        
        if [ ! -f ${LANG_DIR}/L.fst ]; then
            log "Converting L.pt to L.fst"
            ../shared/convert-k2-to-openfst.py \
                --olabels aux_labels \
                ${LANG_DIR}/L.pt \
                ${LANG_DIR}/L.fst
        fi
        
        if [ ! -f ${LANG_DIR}/L_disambig.fst ]; then
            log "Converting L_disambig.pt to L_disambig.fst"
            ../shared/convert-k2-to-openfst.py \
                --olabels aux_labels \
                ${LANG_DIR}/L_disambig.pt \
                ${LANG_DIR}/L_disambig.fst
        fi
    done
fi

# Stage 12: Prepare word level G
if [ $stage -le 12 ] && [ $stop_stage -ge 12 ]; then
    log "Stage 12: Prepare word level G"
    mkdir -p ${LM_DIR}
    
    for vocab_size in ${vocab_sizes[@]}; do
        LANG_DIR=${LANG_BPE}_${vocab_size}  

        if [ ! -f ${LANG_DIR}/transcript_tokens.txt ]; then
            ${LOCAL_PATH}/convert_transcript_words_to_tokens.py \
                --lexicon ${LANG_DIR}/lexicon.txt \
                --transcript ${LANG_DIR}/transcript_words.txt \
                --oov "<UNK>" \
                > ${LANG_DIR}/transcript_tokens.txt
        fi
    
        # 3-gram used in building HLG, 4-gram used for LM rescoring
        for ngram in 2 3 4; do
            if [ ! -f ${LM_DIR}/${ngram}gram.arpa ]; then
                ../shared/make_kn_lm.py \
                    -ngram-order ${ngram} \
                    -text ${LANG_DIR}/transcript_tokens.txt \
                    -lm ${LM_DIR}/${ngram}gram.arpa
            fi
            
            if [ ! -f ${LANG_DIR}/lm/${ngram}gram.fst.txt ]; then
                python3 -m kaldilm \
                    --read-symbol-table="${LANG_DIR}/tokens.txt" \
                    --disambig-symbol='#0' \
                    --max-order=${ngram} \
                    --max-arpa-warnings=-1 \
                    ${LM_DIR}/${ngram}gram.arpa > ${LM_DIR}/G_${ngram}_gram.fst.txt
            fi
        done

        if [ ! -f ${LANG_DIR}/HL.fst ]; then
            ${LOCAL_PATH}/prepare_lang_fst.py \
                --lang-dir ${LANG_DIR} \
                --ngram-G ${LM_DIR}/G_3_gram.fst.txt
        fi
    done
fi

# Stage 13: Compile HLG
if [ $stage -le 13 ] && [ $stop_stage -ge 13 ]; then
    log "Stage 13: Compile HLG"
    
    for vocab_size in ${vocab_sizes[@]}; do
        LANG_DIR=${LANG_BPE}_${vocab_size}  
        ${LOCAL_PATH}/compile_hlg.py --lang-dir ${LANG_DIR}
        
        # Note: If ${LOCAL_PATH}/compile_hlg.py throws OOM,
        # please switch to the following command:
        # ${LOCAL_PATH}/compile_hlg_using_openfst.py --lang-dir ${LANG_DIR}
    done
fi