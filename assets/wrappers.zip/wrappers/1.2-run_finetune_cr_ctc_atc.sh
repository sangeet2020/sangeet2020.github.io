#!/bin/bash

# MODEL: zipformer + pruned-transducer w/ CR-CTC

export CUDA_VISIBLE_DEVICES="0,1,2,3"
## --causal 1 is for streaming ASR training

SEED=1200
WORLD_SIZE=4
NUM_EPOCHS=20
START_EPOCH=1
USE_FP16=1
CAUSAL=1
DO_FINETUNE=1

PREFIX=atc  #ukostt
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR
MANIFEST_DIR=${ROOT}/data/${PREFIX}/${SET}/fbank/

MAX_DURATION=300
EXP_DIR=${ROOT}/expt/exp-causal-cr-ctc-ft/${PREFIX}/${SEED}
MASTER_PORT=12345
START_BATCH=0
BASE_LR=0.0045
ENABLE_MUSAN=False
ZIPFORMER_PATH=${ROOT}/zipformer

# Finetuning params
PRETRAINED_PATH=/mnt/amtmpvf2/sangeet/backup/Bilingual-EN-CV_Deu16/zipformer/causal-model-medium-66M-params
BPE_MODEL=${PRETRAINED_PATH}/tokenizer/bpe.model
FINETUNE_CKPT=${PRETRAINED_PATH}/pretrained.pt

# CR-CTC Specific Params
USE_CR_CTC=1
USE_CTC=1
USE_TRANSDUCER=1
USE_ATTENTION_DECODER=0
ENABLE_SPEC_AUG=False
CTC_LOSS_SCALE=0.1
CR_LOSS_SCALE=0.02
TIME_MASK_RATIO=2.5

mkdir -p ${EXP_DIR}
cp "$0" ${EXP_DIR}

python ${ZIPFORMER_PATH}/finetune.py \
    --prefix ${PREFIX} \
    --seed ${SEED} \
    --world-size $WORLD_SIZE \
    --finetune-ckpt ${FINETUNE_CKPT} \
    --do-finetune ${DO_FINETUNE} \
    --manifest-dir "$MANIFEST_DIR" \
    --exp-dir ${EXP_DIR} \
    --num-epochs $NUM_EPOCHS \
    --start-epoch $START_EPOCH \
    --use-fp16 $USE_FP16 \
    --causal $CAUSAL \
    --bpe-model "$BPE_MODEL" \
    --max-duration $MAX_DURATION \
    --master-port $MASTER_PORT \
    --start-batch $START_BATCH \
    --base-lr $BASE_LR \
    --enable-musan $ENABLE_MUSAN \
    --use-cr-ctc ${USE_CR_CTC} \
    --use-ctc ${USE_CTC} \
    --use-transducer ${USE_TRANSDUCER} \
    --use-attention-decoder ${USE_ATTENTION_DECODER} \
    --enable-spec-aug $ENABLE_SPEC_AUG \
    --ctc-loss-scale ${CTC_LOSS_SCALE} \
    --cr-loss-scale ${CR_LOSS_SCALE} \
    --time-mask-ratio ${TIME_MASK_RATIO} \