#!/usr/bin/env bash

set -eou pipefail

# Default parameters
nj=24
stage=-1
stop_stage=100
num_splits=5  # Split dataset to avoid OOM during feature extraction
dataset=all_data
lang=en
PREFIX=tse	# IMPORTANT parameter. eg. eng16, deu16, ru...

# Directory paths
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs
DATA_DIR=/mnt/local/sangeet/workncode/wesep/examples/librimix/tse/v2/ASR/evalwp_testset/temp/ls_est_source_clean
OUTPUT_DIR=${ROOT}/UkOSTT/ASR/data/${PREFIX}/${dataset}
MUSAN_MANIFESTS_DIR=${ROOT}/Deu16/ASR/data/Deu16/all_data
MANIFEST_DIR=${OUTPUT_DIR}/manifests
FBANK_DIR=${OUTPUT_DIR}/fbank
LANG_BPE=${OUTPUT_DIR}/lang_bpe
LM_DIR=${OUTPUT_DIR}/lm
LOCAL_PATH=${ROOT}/UkOSTT/ASR/local

# Logs
LOGS_DIR=${OUTPUT_DIR}/logs
mkdir -p ${LOGS_DIR}
LOG_FILE="${LOGS_DIR}/prepare_data_$(date +%Y%m%d_%H%M%S).log"

exec &> >(tee -a "${LOG_FILE}")

echo "Script started at $(date)"
echo "Logging to ${LOG_FILE}"


. ../shared/parse_options.sh || exit 1

# Vocab sizes for sentence piece models
# Will generate ${OUTPUT_DIR}/lang_bpe_xxx for each size
vocab_sizes=(500)

# Create output directory
mkdir -p ${OUTPUT_DIR}

# Logging function (from espnet)
log() {
    local fname=${BASH_SOURCE[1]##*/}
    echo -e "\n$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $* ********"
}

# Check for ffmpeg requirement
if ! command -v ffmpeg &> /dev/null; then
    echo "This dataset requires ffmpeg"
    echo "Please install ffmpeg first"
    echo ""
    echo "  sudo apt-get install ffmpeg"
    exit 1
fi

# Stage 0: Download Musan data
if [ $stage -le 0 ] && [ $stop_stage -ge 0 ]; then
    log "Stage 0: Download Musan data"
    log "No need, using old download at /mnt/local/sangeet/data/Deu16/musan"
fi

# Stage 1: Prepare manifests
if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
    log "Stage 1: Prepare ${PREFIX} manifests"
    mkdir -p ${MANIFEST_DIR}
    if [ ! -e ${MANIFEST_DIR}/.${PREFIX}.done ]; then
        python ls_tse_out.py ${DATA_DIR} ${MANIFEST_DIR} --num_jobs 16
        touch ${MANIFEST_DIR}/.${PREFIX}.done
    fi
fi

# Stage 2: Prepare musan manifest
if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
    log "Stage 2: Prepare musan manifest"
    mkdir -p ${MANIFEST_DIR}
    if [ ! -e ${MANIFEST_DIR}/.musan.done ]; then
        ln -svf $(realpath ${MUSAN_MANIFESTS_DIR}/manifests/musan_*) \
            ${MANIFEST_DIR}
        touch ${MANIFEST_DIR}/.musan.done
    fi
fi

# Stage 3: Preprocess manifest
if [ $stage -le 3 ] && [ $stop_stage -ge 3 ]; then
    log "Stage 3: Preprocess ${PREFIX} manifest (data cleaning and normalizing)"
    if [ ! -e ${FBANK_DIR}/.preprocess_complete ]; then
        ${LOCAL_PATH}/preprocess_cuts.py \
            --prefix ${PREFIX} \
            --lang ${lang} \
            --src-dir ${MANIFEST_DIR} \
            --output-dir ${FBANK_DIR}
        touch ${FBANK_DIR}/.preprocess_complete
    fi
fi

# Stage 4: Compute fbank for dev and test
if [ $stage -le 4 ] && [ $stop_stage -ge 4 ]; then
    log "Stage 4: Compute fbank for dev and test subsets of ${PREFIX}"
    mkdir -p ${FBANK_DIR}
    if [ ! -e ${FBANK_DIR}/.${PREFIX}_dev_test.done ]; then
        ${LOCAL_PATH}/compute_fbank_dev_test.py \
            --prefix ${PREFIX} \
            --output-dir ${FBANK_DIR}
        touch ${FBANK_DIR}/.${PREFIX}_dev_test.done
    fi
fi

# Stage 5: Split train subset
if [ $stage -le 5 ] && [ $stop_stage -ge 5 ]; then
    log "Stage 5: Split train subset into ${num_splits} pieces"
    split_dir=${FBANK_DIR}/${PREFIX}_train_split_${num_splits}
    if [ ! -e $split_dir/.${PREFIX}_train_split.done ]; then
        lhotse split $num_splits -i 1 \
            ${FBANK_DIR}/${PREFIX}_cuts_train_raw.jsonl.gz \
            $split_dir
        touch $split_dir/.${PREFIX}_train_split.done
    fi
fi

# Stage 6: Compute fbank for train
if [ $stage -le 6 ] && [ $stop_stage -ge 6 ]; then
    log "Stage 6: Compute fbank train subset of ${PREFIX}"
    if [ ! -e ${FBANK_DIR}/.${PREFIX}_train.done ]; then
        ${LOCAL_PATH}/compute_fbank_train_splits.py \
            --prefix ${PREFIX} \
            --output-dir ${FBANK_DIR} \
            --num-workers $nj \
            --batch-duration 600 \
            --start 0 \
            --num-splits $num_splits
        touch ${FBANK_DIR}/.${PREFIX}_train.done
    fi
fi

# Stage 7: Combine features for train
if [ $stage -le 7 ] && [ $stop_stage -ge 7 ]; then
    log "Stage 7: Combine features for train"
    if [ ! -e ${FBANK_DIR}/${PREFIX}_cuts_train.jsonl.gz ]; then
        pieces=$(find ${FBANK_DIR}/${PREFIX}_train_split_${num_splits} \
            -name "${PREFIX}_cuts_train.*.jsonl.gz")
        lhotse combine $pieces ${FBANK_DIR}/${PREFIX}_cuts_train.jsonl.gz
    fi
    # Pre-shuffle the whole manifest 
    cat <(gunzip -c ${FBANK_DIR}/${PREFIX}_cuts_train.jsonl.gz) | \
        shuf | \
        gzip -c > ${FBANK_DIR}/${PREFIX}_cuts_train_shuf.jsonl.gz
fi

# Stage 8: Display manifest statistics
if [ $stage -le 8 ] && [ $stop_stage -ge 8 ]; then
    log "Stage 8: Display statistics"
    ${LOCAL_PATH}/display_manifest_statistics.py \
        --prefix ${PREFIX} \
        --output-dir ${FBANK_DIR}
fi

# Stage 9: Compute fbank for musan
if [ $stage -le 9 ] && [ $stop_stage -ge 9 ]; then
    log "Stage 9: Compute fbank for musan"
    mkdir -p ${FBANK_DIR}
    if [ ! -e ${FBANK_DIR}/.musan.done ]; then
        ln -svf $(realpath ${MUSAN_MANIFESTS_DIR}/fbank/musan_*) ${FBANK_DIR}
        touch ${FBANK_DIR}/.musan.done
    fi
fi