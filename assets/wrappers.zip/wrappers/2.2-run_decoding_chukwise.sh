#!/bin/bash

set -eou pipefail

# Note: For decoding mode, simulated streaming indicates 
# feeding full utterance during decoding using decode.py, 
# while chunk-size indicates feeding certain number of frames 
# at each time using streaming_decode.py.


export CUDA_VISIBLE_DEVICES="2"
## --causal 1 is for streaming ASR training
stage=-1
stop_stage=100

log() {
  # This function is from espnet
  local fname=${BASH_SOURCE[1]##*/}
  echo -e "\n$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $* ********"
}

. shared/parse_options.sh || exit 1


## --causal 1 is for streaming ASR training
# Standard params
SEED=1800
EPOCH=30
ITER=0
AVG=8
USE_AVERAGED_MODEL=True

ROOT_DIR=data/Multi_dataset/all_data
BPE_MODEL=${ROOT_DIR}/lang_bpe_500/unigram_500.model
MANIFEST_DIR=${ROOT_DIR}/fbank
EXP_DIR=zipformer/exp-causal/${SEED}

CHUNK_SIZE=32
CAUSAL=1
LEFT_CONTEXT_FRAMES=128

NUM_ACTIVE_PATHS=8
BEAM=4.0
MAX_CONTEXTS=8
MAX_STATES=32
CONTEXT_SIZE=2
NUM_DECODE_STREAMS=500

# Training arguments: Medium scale model (66M params)
NUM_ENCODER_LAYERS="2,2,3,4,3,2"
FEEDFORWARD_DIM="512,768,1024,1536,1024,768"
ENCODER_DIM="192,256,384,512,384,256"
ENCODER_UNMASKED_DIM="192,192,256,256,256,192"

# LM params
BEAM_SIZE=4
LANG_DIR=${ROOT_DIR}/lm/

LM_DIR=../LM/my-rnnlm-exp/1200  # LM trained using data/Deu16/all_data/lang_bpe_500/bpe.model tokenizer and full Deu16 train text.
LM_EPOCH=19
LM_AVG=2
LM_TYPE=rnn         #   ["rnn", "transformer"]
LM_SCALE=0.3        # Used only when `--use-shallow-fusion` is set to True
TOKENS_NGRAM=2
BACKOFF_ID=500
CONTEXT_SCORE=2     # The bonus score of each token for the context biasing words/phrases. Used only when --decoding-method is modified_beam_search and modified_beam_search_LODR.


# Chunk-wise streaming decoding command (without external LM)
function run_decode() {
    ./zipformer/multi_dataset_streaming_decode.py \
        --epoch ${EPOCH} \
        --iter ${ITER} \
        --avg ${AVG} \
        --use-averaged-model ${USE_AVERAGED_MODEL} \
        --exp-dir ${EXP_DIR} \
        --bpe-model ${BPE_MODEL} \
        --manifest-dir ${MANIFEST_DIR} \
        --num-encoder-layers "$NUM_ENCODER_LAYERS" \
        --encoder-dim "$ENCODER_DIM" \
        --feedforward-dim "$FEEDFORWARD_DIM" \
        --encoder-unmasked-dim "$ENCODER_UNMASKED_DIM" \
        --num_active_paths ${NUM_ACTIVE_PATHS} \
        --beam ${BEAM} \
        --max-contexts ${MAX_CONTEXTS} \
        --max-states ${MAX_STATES} \
        --context-size ${CONTEXT_SIZE} \
        --causal ${CAUSAL} \
        --chunk-size ${CHUNK_SIZE} \
        --left-context-frames ${LEFT_CONTEXT_FRAMES} \
        --num-decode-streams ${NUM_DECODE_STREAMS} \
        --enable-musan False \
        --enable-spec-aug False \
        --on-the-fly-feats True \
        --lm-exp-dir ${LM_DIR} \
        --lm-type ${LM_TYPE} \
        --lm-epoch ${LM_EPOCH} \
        --tokens-ngram ${TOKENS_NGRAM} \
        --context-score ${CONTEXT_SCORE} \
        --backoff-id ${BACKOFF_ID} \
        --lm-avg ${LM_AVG} \
        --rnn-lm-embedding-dim 2048 \
        --rnn-lm-hidden-dim 2048 \
        --rnn-lm-num-layers 3 \
        --rnn-lm-tie-weights 1 \
        --lm-vocab-size 500 \
        "$@"
}

if [ $stage -le 0 ] && [ $stop_stage -ge 0 ]; then
    log "Stage 0: Using greedy decoding and no external LM"
    export CUDA_VISIBLE_DEVICES="5"
    run_decode --decoding-method greedy_search &
fi

# if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
#     export CUDA_VISIBLE_DEVICES="1"
#     log "Stage 1: Using fasr beam search and no external LM"
#     run_decode --decoding-method fast_beam_search
# fi

if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
    log "Stage 2: Using modified beam search and no external LM"
    export CUDA_VISIBLE_DEVICES="6"
    run_decode --decoding-method modified_beam_search &
fi


if [ $stage -le 3 ] && [ $stop_stage -ge 3 ]; then
    export CUDA_VISIBLE_DEVICES="7"
    log "Stage 3: Using modified beam search with LODR (to counter ILM) and an external LM "
    LM_SCALE=0.43   # for the external LM
    LODR_SCALE=-0.24    # A low order n-gram kenLM, whose score will be subtracted during shallow fusion
    USE_SHALLOW_FUSION=True
    run_decode --decoding-method modified_beam_search_LODR \
    --lang-dir ${LANG_DIR} \
    --ngram-lm-scale ${LODR_SCALE} \
    --lm-scale ${LM_SCALE} \
    --use-shallow-fusion ${USE_SHALLOW_FUSION} &
fi