#!/bin/bash

export CUDA_VISIBLE_DEVICES="0,1,2,3,4,5,6,7"
## --causal 1 is for streaming ASR training

SEED=10
WORLD_SIZE=1
NUM_EPOCHS=30
START_EPOCH=1
USE_FP16=1
CAUSAL=1

PREFIX=atc  #ukostt
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR
BPE_MODEL=${ROOT}/data/${PREFIX}/${SET}/lang_bpe_500/bpe.model
MANIFEST_DIR=${ROOT}/data/${PREFIX}/${SET}/fbank/

MAX_DURATION=500
EXP_DIR=${ROOT}/expt/exp-causal/${PREFIX}/${SEED}
MASTER_PORT=12345
START_BATCH=0
BASE_LR=0.045     # when fine-tuing 0.0045
ENABLE_SPEC_AUG=True
ENABLE_MUSAN=False
ZIPFORMER_PATH=${ROOT}/zipformer

mkdir -p ${EXP_DIR}
cp "$0" ${EXP_DIR}

python ${ZIPFORMER_PATH}/train.py \
   --prefix ${PREFIX} \
   --seed ${SEED} \
   --world-size $WORLD_SIZE \
   --exp-dir ${EXP_DIR} \
   --num-epochs $NUM_EPOCHS \
   --start-epoch $START_EPOCH \
   --use-fp16 $USE_FP16 \
   --causal $CAUSAL \
   --bpe-model "$BPE_MODEL" \
   --manifest-dir "$MANIFEST_DIR" \
   --max-duration $MAX_DURATION \
   --master-port $MASTER_PORT \
   --start-batch $START_BATCH \
   --base-lr $BASE_LR \
   --enable-spec-aug $ENABLE_SPEC_AUG \
   --enable-musan $ENABLE_MUSAN \
   
