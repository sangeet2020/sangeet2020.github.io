#!/bin/bash

set -euo pipefail

# Simulated streaming decodes a full utterance using decode.py,
# while chunkwise feeds frames incrementally using streaming_decode.py.

export CUDA_VISIBLE_DEVICES="3"

stage=-1
stop_stage=100

log() {
    local fname=${BASH_SOURCE[1]##*/}
    echo -e "\n$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $* ********"
}

. ../shared/parse_options.sh || exit 1

# Standard parameters
SEED=1800
EPOCH=30
ITER=0
AVG=8
CAUSAL=1
MAX_DURATION=600
USE_AVERAGED_MODEL=True

PREFIX=Multi_dataset
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/Eng16/ASR

MANIFEST_DIR=${ROOT}/data/${PREFIX}/${SET}/fbank/
EXP_DIR=${ROOT}/expt/base_model/exp-causal/${SEED}
BPE_MODEL=${EXP_DIR}/tokenizer/bpe.model

ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR
ZIPFORMER_PATH=${ROOT}/zipformer

MULTIDATASET_DECODING=True
PREFIX_LIST="Eng16"

# Decoding parameters
BEAM_SIZE=4
LANG_DIR=${ROOT}/data/${PREFIX}/${SET}/lm/
CHUNK_SIZE=32
LEFT_CONTEXT_FRAMES=128

# Language Model (LM) parameters
LM_DIR=${ROOT}/../LM/my-rnnlm-exp/1200
LM_EPOCH=19
LM_AVG=3
LM_TYPE=rnn
LM_SCALE=0.3
TOKENS_NGRAM=3

run_decode() {
    python ${ZIPFORMER_PATH}/decode.py \
        --prefix ${PREFIX} \
        --epoch ${EPOCH} \
        --iter ${ITER} \
        --avg ${AVG} \
        --use-averaged-model ${USE_AVERAGED_MODEL} \
        --exp-dir ${EXP_DIR} \
        --bpe-model ${BPE_MODEL} \
        --lang-dir ${LANG_DIR} \
        --manifest-dir ${MANIFEST_DIR} \
        --max-duration ${MAX_DURATION} \
        --beam-size ${BEAM_SIZE} \
        --causal ${CAUSAL} \
        --chunk-size ${CHUNK_SIZE} \
        --left-context-frames ${LEFT_CONTEXT_FRAMES} \
        --lm-exp-dir ${LM_DIR} \
        --lm-type ${LM_TYPE} \
        --lm-epoch ${LM_EPOCH} \
        --tokens-ngram ${TOKENS_NGRAM} \
        --lm-avg ${LM_AVG} \
        --lm-scale ${LM_SCALE} \
        --enable-multidataset-decoding ${MULTIDATASET_DECODING} \
        --multidataset-prefix-list "${PREFIX_LIST}" \
        "$@"
}

if [ $stage -le 0 ] && [ $stop_stage -ge 0 ]; then
    log "Stage 0: Greedy decoding without external LM"
    USE_SHALLOW_FUSION=False
    NGRAM_LM_SCALE=0.01
    run_decode \
        --decoding-method greedy_search \
        --use-shallow-fusion ${USE_SHALLOW_FUSION} \
        --ngram-lm-scale ${NGRAM_LM_SCALE}
fi

if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
    log "Stage 1: Modified beam search without external LM"
    USE_SHALLOW_FUSION=False
    NGRAM_LM_SCALE=0.01
    run_decode \
        --decoding-method modified_beam_search \
        --use-shallow-fusion ${USE_SHALLOW_FUSION} \
        --ngram-lm-scale ${NGRAM_LM_SCALE}
fi

if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
    log "Stage 2: Modified beam search with shallow fusion and external LM"
    LM_SCALE=0.23
    USE_SHALLOW_FUSION=True
    run_decode \
        --decoding-method modified_beam_search_lm_shallow_fusion \
        --lm-scale ${LM_SCALE} \
        --use-shallow-fusion ${USE_SHALLOW_FUSION}
fi

if [ $stage -le 3 ] && [ $stop_stage -ge 3 ]; then
    log "Stage 3: Modified beam search with LODR and external LM"
    LM_SCALE=0.42
    LODR_SCALE=-0.24
    USE_SHALLOW_FUSION=True
    run_decode \
        --decoding-method modified_beam_search_LODR \
        --enable-multidataset-decoding True \
        --ngram-lm-scale ${LODR_SCALE} \
        --lm-scale ${LM_SCALE} \
        --use-shallow-fusion ${USE_SHALLOW_FUSION}
fi

if [ $stage -le 4 ] && [ $stop_stage -ge 4 ]; then
    log "Stage 4: Modified beam search with LM rescoring"
    LM_SCALE=0.29
    USE_SHALLOW_FUSION=False
    run_decode \
        --decoding-method modified_beam_search_lm_rescore \
        --lm-scale ${LM_SCALE} \
        --use-shallow-fusion ${USE_SHALLOW_FUSION}
fi

if [ $stage -le 5 ] && [ $stop_stage -ge 5 ]; then
    log "Stage 5: LM rescoring with LODR and external LM"
    LM_SCALE=0.43
    LODR_SCALE=-0.24
    USE_SHALLOW_FUSION=True
    run_decode \
        --decoding-method modified_beam_search_lm_rescore_LODR \
        --ngram-lm-scale ${LODR_SCALE} \
        --lm-scale ${LM_SCALE} \
        --use-shallow-fusion ${USE_SHALLOW_FUSION}
fi
