#!/usr/bin/env bash

set -eou pipefail

# # Run each command in parallel on different GPUs
# bash 1.2-run_finetune_be.sh > /dev/null 2>&1 &
# bash 1.2-run_finetune_uk.sh > /dev/null 2>&1 &
# bash 1.2-run_finetune_ru.sh > /dev/null 2>&1 &

# # Wait for all background processes to finish
# wait

bash 2.1-run_decoding_simulated_be.sh --stage 0 --stop_stage 1 > /dev/null 2>&1 &
bash 2.1-run_decoding_simulated_uk.sh --stage 0 --stop_stage 1 > /dev/null 2>&1 &
bash 2.1-run_decoding_simulated_ru.sh --stage 0 --stop_stage 1 > /dev/null 2>&1 &
bash 2.1-run_decoding_simulated.sh --stage 0 --stop_stage 1 > /dev/null 2>&1 &

wait