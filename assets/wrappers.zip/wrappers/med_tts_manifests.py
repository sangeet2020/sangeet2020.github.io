"""
DEU16 data Laternenumzugepration script.
Author: Sangeet Sagar 2023
"""

import logging
import math
import numbers
import shutil
import tarfile
import warnings
from collections import defaultdict
from concurrent.futures.thread import ThreadPoolExecutor
from concurrent.futures.process import ProcessPoolExecutor
from contextlib import contextmanager
from multiprocessing import get_context as mp_get_context
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple, Union

from tqdm.auto import tqdm

from lhotse import (
    get_ffmpeg_torchaudio_info_enabled,
    load_manifest,
    set_ffmpeg_torchaudio_info_enabled,
    validate_recordings_and_supervisions,
)
from lhotse.audio import Recording, RecordingSet
from lhotse.qa import fix_manifests
from lhotse.supervision import SupervisionSegment, SupervisionSet
from lhotse.utils import Pathlike, is_module_available, resumable_download, safe_extract

import os
import random
import torchaudio
import pdb
import argparse


LANGUAGE="de"
DATA_SPLITS = (
    "train",
    "valid",
    "test"
)
PREFIX='med_tts'

@contextmanager
def disable_ffmpeg_torchaudio_info() -> None:
    enabled = get_ffmpeg_torchaudio_info_enabled()
    set_ffmpeg_torchaudio_info_enabled(False)
    try:
        yield
    finally:
        set_ffmpeg_torchaudio_info_enabled(enabled)


def _read_deu16_manifests_if_cached(
    output_dir: Optional[Pathlike],
    prefix:str= PREFIX,
) -> Dict[str, Dict[str, Union[RecordingSet, SupervisionSet]]]:
    """
    Returns:
        {'train': {'recordings': ..., 'supervisions': ...}, 'valid': ..., 'test': ...}
    """
    if output_dir is None:
        return {}
    manifests = defaultdict(dict)
    for part in ["train", "valid", "test"]:
        for manifest in ["recordings", "supervisions"]:
            path = output_dir / f"{prefix}_{manifest}_{part}.jsonl.gz"
            if not path.is_file():
                continue
            manifests[part][manifest] = load_manifest(path)
    return manifests


def prepare_deu16(
    corpus_dir: Pathlike,
    output_dir: Pathlike,
    splits: Union[str, Sequence[str]] = DATA_SPLITS,
    prefix:str= PREFIX,
    language:str = LANGUAGE,
    num_jobs: int = 1,
) -> Dict[str, Dict[str, Dict[str, Union[RecordingSet, SupervisionSet]]]]:
    """
    Returns the manifests which consist of the Recordings and Supervisions.
    When all the manifests are available in the ``output_dir``, it will simply read and return them.

    Returns a dict with 3-level structure (split -> manifest-type)::

        >>> {'train/valid/test': {'recordings/supervisions': manifest}}

    :param corpus_dir: Pathlike, the path to the corpus.
    :param output_dir: Pathlike, the path where to write the manifests.
    :param splits: by default ``['train', 'valid', 'test']``
    :param num_jobs: How many concurrent workers to use for scanning of the audio files.
    :return: a dict with manifests for all specified languagues and their train/valid/test splits.
    """
    corpus_dir = Path(corpus_dir)
    assert corpus_dir.is_dir(), f"No such directory: {corpus_dir}"
    assert output_dir is not None, (
        "Deu16 recipe requires to specify the output "
        "manifest directory (output_dir cannot be None)."
    )
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Maybe the manifests already exist: we can read them and save a bit of preparation time.
    # Pattern: "deu16_recordings_train.jsonl.gz" / "deu16_supervisions_train.jsonl.gz"
    deu16_manifests = _read_deu16_manifests_if_cached(output_dir=output_dir, prefix=prefix)

    for part in tqdm(splits, desc=f"Splitting"):
        logging.info(f"Splitting {part}")
        if part in deu16_manifests:
            logging.info(f"{part} split of Deu16 already prepared - skipping.")
            continue
        recording_set, supervision_set = _prepare_part(
            part=part,
            corpus_dir=corpus_dir,
            language=language,
            num_jobs=num_jobs,
        )

        supervision_set.to_file(output_dir / f"{prefix}_supervisions_{part}.jsonl.gz")
        recording_set.to_file(output_dir / f"{prefix}_recordings_{part}.jsonl.gz")

        deu16_manifests[part] = {
            "supervisions": supervision_set,
            "recordings": recording_set,
        }

    return deu16_manifests


def _prepare_part(
    part: str,
    corpus_dir: Pathlike,
    language: str,
    num_jobs: int = 1,
) -> Tuple[RecordingSet, SupervisionSet]:
    """
    Prepares part (train/test/valid) of Deu16 dataset.

    :param part: which split to prepare (e.g., "train", "valid", "test").
    :param corpus_dir: Pathlike, the path to the corpus.
    :param num_jobs: How many concurrent workers to use for scanning of the audio files.
    :return: a tuple of (RecordingSet, SupervisionSet) objects,
        note that the manifests may be fairly large in memory.
    """

    # with disable_ffmpeg_torchaudio_info():
    #     with ProcessPoolExecutor(
    #         max_workers=num_jobs,
    #         mp_context=mp_get_context("spawn"),
    #     ) as ex:
    
    # with disable_ffmpeg_torchaudio_info():
    with ThreadPoolExecutor(num_jobs) as ex:
        futures = []
        recordings = []
        supervisions = []

        for file in tqdm(
            Path(os.path.join(corpus_dir, part, 'wav')).glob("*.wav"), desc="Distributing tasks"
        ):  
            audio_path = file
            text_path = Path(os.path.join(corpus_dir, part, 'txt', file.stem+".txt"))
            futures.append(
                ex.submit(
                    _parse_utterance,
                    audio_path,
                    text_path,
                    language
                )
            )

        for future in tqdm(futures, desc="Processing"):
            result = future.result()
            if result is None:
                continue
            recording, segment = result
            recordings.append(recording)
            supervisions.append(segment)

        recording_set = RecordingSet.from_recordings(recordings)
        supervision_set = SupervisionSet.from_segments(supervisions)
        
        # Fix manifests
        recording_set, supervision_set = fix_manifests(recording_set, supervision_set)
        validate_recordings_and_supervisions(recording_set, supervision_set)

    return recording_set, supervision_set


def _parse_utterance(
    audio_path: str,
    text_path: str,
    language: str,
) -> Optional[Tuple[Recording, SupervisionSegment]]:

    duration = get_audio_duration(audio_path)
    words = open(text_path, encoding="utf-8").read().strip()
    segment_id = os.path.basename(audio_path.name)
    
    if language.lower() != "en":
        # Skip English sentences
        if "English" in str(audio_path):
            return None
    
    # Remove super short utts
    if duration < 1.0:
        return None
    
    recording = Recording.from_file(audio_path, recording_id=segment_id)
    segment = SupervisionSegment(
        id=segment_id,
        recording_id=segment_id,
        start=0,
        duration=duration,
        channel=0,
        language=language,
        speaker="",
        text=words,
    )
    return recording, segment


def get_audio_duration(file_path):
    waveform, sample_rate = torchaudio.load(file_path)
    duration = waveform.shape[1] / sample_rate
    return duration


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--splits", nargs="+", default=DATA_SPLITS)
    parser.add_argument("--corpus_dir", type=Path, required=True)
    parser.add_argument("--output_dir", type=Path, required=True)
    parser.add_argument("--prefix", type=str, required=True)
    parser.add_argument("--language", type=str, default="de")
    parser.add_argument("--num_jobs", type=int, default=1)

    args = parser.parse_args()

    if not args.corpus_dir.exists():
        parser.error(f"corpus_dir does not exist: {args.corpus_dir}")

    return args

if __name__ == "__main__":
    args = parse_args()
    prepare_deu16(
        splits=args.splits,
        corpus_dir=args.corpus_dir,
        output_dir=args.output_dir,
        language=args.language,
        num_jobs=args.num_jobs,
    )