#!/usr/bin/env bash

set -eou pipefail

stage=-1
stop_stage=100
. ../shared/parse_options.sh || exit 1

SEED=1200
PREFIX=atc
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR

SOURCE_DIR=${ROOT}/expt/exp-causal/${PREFIX}/${SEED}
DIR_NAME=Zipformer-${PREFIX}    # Dir name in backup folder
ZIPFORMER_PATH=${ROOT}/zipformer

TARGET_DIR_BASE=/mnt/amtmpvf2/sangeet/backup/
START_EPOCH=22
END_EPOCH=30
MODEL_TYPE=icefall/zipformer
MODEL_IDENTIFIER=${PREFIX}-causal-model-medium-66M-params
TOKENIZER_PATH=${SOURCE_DIR}/tokenizer/

TARGET_DIR="${TARGET_DIR_BASE}/${DIR_NAME}/${MODEL_TYPE}/${MODEL_IDENTIFIER}"
CUSTOM_PREFIX=${PREFIX}-ft-16k-med-k2 	# in EMLWP dir
VERSION=v1

README_MSG="This streaming Zipformer model was trained on mixture of ATC (LDC+FRA_airport+ATCOSIM) data 
using pruned RNNT training mechanism, with Zipformer as the encoder.
No pre-trained models were used.
Model size: Medium 66M params.
Modified BS WER=3.4; Greedy Search WER=4.28
Punctuations were not used used in the training data"

# Create the target directory if it doesn't exist
mkdir -p "$TARGET_DIR"


log() {
  # This function is from espnet
  local fname=${BASH_SOURCE[1]##*/}
  echo -e "\n$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $* ********"
}

if [ $stage -le 0 ] && [ $stop_stage -ge 0 ]; then
    log "Stage 0: Backup checkpoints, logs, test results"
    
    # Copy the checkpoints between the specified epochs
    for (( epoch=$START_EPOCH; epoch<=$END_EPOCH; epoch++ )); do
        cp "${SOURCE_DIR}/epoch-${epoch}.pt" "$TARGET_DIR"
    done

    # Copy logs
    cp -r "${SOURCE_DIR}/log" "$TARGET_DIR"

	# Copy test results
	if ! cp -r "${SOURCE_DIR}"/*test_results* "$TARGET_DIR"; then
		echo "Warning: Failed to copy test results from ${SOURCE_DIR} to ${TARGET_DIR}" >&2
	fi


    # Copy bpe.model and tokens.txt from the tokenizer path
	mkdir -p ${TARGET_DIR}/tokenizer
    cp "${TOKENIZER_PATH}/bpe.model" "${TARGET_DIR}/tokenizer/"
    cp "${TOKENIZER_PATH}/tokens.txt" "${TARGET_DIR}/tokenizer/"
    cp "${TOKENIZER_PATH}/unigram_500.vocab" "${TARGET_DIR}/tokenizer/"
fi

if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
    log "Stage 1: Run model onnx export"

    EPOCH=${END_EPOCH}
    AVG=$((END_EPOCH - START_EPOCH))
    EXP_DIR=${TARGET_DIR}
    BPE_MODEL=${EXP_DIR}/tokenizer/bpe.model
    TOKENS=${EXP_DIR}/tokenizer/tokens.txt

    CAUSAL=1
    CHUNK_SIZE=32
    LEFT_CONTEXT_FRAMES=128

    USE_AVERAGED_MODEL=1

    # Export the model from PyTorch to ONNX
    python ${ZIPFORMER_PATH}/export-onnx-streaming.py \
        --tokens ${TOKENS} \
        --use-averaged-model ${USE_AVERAGED_MODEL} \
        --epoch ${EPOCH} \
        --avg ${AVG} \
        --exp-dir ${EXP_DIR} \
        --causal ${CAUSAL} \
        --chunk-size ${CHUNK_SIZE} \
        --left-context-frames ${LEFT_CONTEXT_FRAMES}


    # It will generate the following 3 files:

    #   - encoder-epoch-99-avg-1-chunk-16-left-64.onnx
    #   - decoder-epoch-99-avg-1-chunk-16-left-64.onnx
    #   - joiner-epoch-99-avg-1-chunk-16-left-64.onnx

fi

if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
    log "Stage 2: Get models ready to ship to decoding platform"

    DATE=$(date +"%Y%m%d")
    EMLWP_DIR=/mnt/amtmpvf2/sangeet/EMLWP/${CUSTOM_PREFIX}-${DATE}/${VERSION}

    mkdir -p "$EMLWP_DIR"
    
    # Copy all .onnx files from ${TARGET_DIR} to EMLWP_DIR
    cp "${TARGET_DIR}"/*.onnx "$EMLWP_DIR"
    cp "${TARGET_DIR}/tokenizer/tokens.txt"  "$EMLWP_DIR"

    # Convert tokens to lower case
    sed 's/.*/\L&/g' < "$EMLWP_DIR/tokens.txt" > "$EMLWP_DIR/tokens_lc.txt"

# Create cfg.txt inside EMLWP_DIR with the specified lines
cat <<EOL > "$EMLWP_DIR/cfg_stream.txt"
engine.type     = eml-kt-stream
engine.sr       = 16000
engine.nbest    = false

configFile      = \${ADVROOT}/config.json
EOL

    # Find the encoder, decoder, and joiner files in the EMLWP_DIR
    ENCODER_FILE=$(ls "$EMLWP_DIR"/encoder-*.onnx | grep -v 'int8')
	DECODER_FILE=$(ls "$EMLWP_DIR"/decoder-*.onnx | grep -v 'int8')
	JOINER_FILE=$(ls "$EMLWP_DIR"/joiner-*.onnx | grep -v 'int8')

    ENCODER_INT8_FILE=$(ls "$EMLWP_DIR"/encoder-*.int8.onnx)
    DECODER_INT8_FILE=$(ls "$EMLWP_DIR"/decoder-*.int8.onnx)
    JOINER_INT8_FILE=$(ls "$EMLWP_DIR"/joiner-*.int8.onnx)

# Create config.json inside EMLWP_DIR
cat <<EOL > "$EMLWP_DIR/config.json"
{"tokens": "tokens_lc.txt",
"encoder": "$(basename $ENCODER_FILE)",
"decoder": "$(basename $DECODER_FILE)",
"joiner": "$(basename $JOINER_FILE)",
"model_type": "zipformer2",
"decoding_method": "modified_beam_search",
"sampling_rate": 16000}
EOL

# Create config_int8.json inside EMLWP_DIR
cat <<EOL > "$EMLWP_DIR/config_int8.json"
{"tokens": "tokens_lc.txt",
"encoder": "$(basename $ENCODER_INT8_FILE)",
"decoder": "$(basename $DECODER_INT8_FILE)",
"joiner": "$(basename $JOINER_INT8_FILE)",
"model_type": "zipformer2",
"decoding_method": "modified_beam_search",
"sampling_rate": 16000}
EOL

	# Create config_int8.json inside EMLWP_DIR
	touch "$EMLWP_DIR/README.txt"
    echo $README_MSG > "$EMLWP_DIR/README.txt"

	# Zip the dirs
	python /mnt/amtmpvf2/sangeet/EMLWP/zip_dirs.py /mnt/amtmpvf2/sangeet/EMLWP/${CUSTOM_PREFIX}-${DATE} /mnt/amtmpvf2/sangeet/EMLWP_compressed
fi
