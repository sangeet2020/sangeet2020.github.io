#!/bin/bash


export CUDA_VISIBLE_DEVICES="0,1"
## --causal 1 is for streaming ASR training

SEED=5800
WORLD_SIZE=2
NUM_EPOCHS=30
START_EPOCH=1
USE_FP16=1
CAUSAL=1

# NOTES
# 1. Fbank of pre-trained model data. This is used when the 
# goal is to mix new data with the original data to fine-tune.
# This is useful if you want to maintain the performance on the original domain
# 2. Its mostly seen that using tokenizer to the pre-trained model's 
# gives better performance than one generated from the fine-tuning data.

MANIFEST_DIR="data/Multi_dataset/all_data/fbank"

PRETRAINED_PATH=/mnt/amtmpvf2/sangeet/backup/Zipformer-EN-XL/icefall/zipformer/en-xl-causal-model-medium-66M-params/
# BPE_MODEL=${PRETRAINED_PATH}/updated_tokenizer/bpe.model
FINETUNE_CKPT=${PRETRAINED_PATH}/pretrained.pt

# All ATC Fine-tuning data fbank 
FT_MANIFEST_DIR="data/All_ATC_combined/fbank"
BPE_MODEL=data/All_ATC_combined/lang_bpe_500/bpe.model
EXP_DIR=zipformer_mds/exp-causal-atc/${SEED}

MAX_DURATION=400
DO_FINETUNE=1
USE_MUX=0   # check zipformer/multi_dataset.py before using this

# Additional arguments for training
MASTER_PORT=12349
TENSORBOARD=True
START_BATCH=0
BASE_LR=0.0005   #   0.0045 fine-tuning LR
LR_BATCHES=7500
LR_EPOCHS=3.5
REF_DURATION=600           #800
CONTEXT_SIZE=2
PRUNE_RANGE=5
LM_SCALE=0.25
AM_SCALE=0.0
SIMPLE_LOSS_SCALE=0.5
CTC_LOSS_SCALE=0.2
PRINT_DIAGNOSTICS=False
INF_CHECK=False
SAVE_EVERY_N=4000
KEEP_LAST_K=30
AVERAGE_PERIOD=200

# Training arguments
NUM_ENCODER_LAYERS="2,2,3,4,3,2"
DOWNSAMPLING_FACTOR="1,2,4,8,4,2"
FEEDFORWARD_DIM="512,768,1024,1536,1024,768"
NUM_HEADS="4,4,4,8,4,4"
ENCODER_DIM="192,256,384,512,384,256"
QUERY_HEAD_DIM="32"
VALUE_HEAD_DIM="12"
POS_HEAD_DIM="4"
POS_DIM=48
ENCODER_UNMASKED_DIM="192,192,256,256,256,192"
CNN_MODULE_KERNEL="31,31,15,15,15,31"
DECODER_DIM=512
JOINER_DIM=512
CHUNK_SIZE="16,32,64,-1"
LEFT_CONTEXT_FRAMES="64,128,256,-1"
USE_TRANSDUCER=True
USE_CTC=False

# Zipformer arguments
BUCKETING_SAMPLER=True
NUM_BUCKETS=30
CONCATENATE_CUTS=False
DURATION_FACTOR=1.0
GAP=1.0
ON_THE_FLY_FEATS=False
SHUFFLE=True
DROP_LAST=True
RETURN_CUTS=True
NUM_WORKERS=8
ENABLE_SPEC_AUG=True
SPEC_AUG_TIME_WARP_FACTOR=80
ENABLE_MUSAN=False
INPUT_STRATEGY="PrecomputedFeatures"


# Training arguments: Medium scale model (66M params)
NUM_ENCODER_LAYERS="2,2,3,4,3,2"
FEEDFORWARD_DIM="512,768,1024,1536,1024,768"
NUM_HEADS="4,4,4,8,4,4"
ENCODER_DIM="192,256,384,512,384,256"
ENCODER_UNMASKED_DIM="192,192,256,256,256,192"


./zipformer_mds/finetune.py \
    --seed $SEED \
    --world-size $WORLD_SIZE \
    --finetune-ckpt ${FINETUNE_CKPT} \
    --do-finetune ${DO_FINETUNE} \
    --exp-dir ${EXP_DIR} \
    --num-epochs $NUM_EPOCHS \
    --start-epoch $START_EPOCH \
    --use-fp16 $USE_FP16 \
    --causal $CAUSAL \
    --bpe-model "$BPE_MODEL" \
    --manifest-dir "$MANIFEST_DIR" \
    --ft-manifest-dir "$FT_MANIFEST_DIR" \
    --max-duration $MAX_DURATION \
    --master-port $MASTER_PORT \
    --tensorboard $TENSORBOARD \
    --start-batch $START_BATCH \
    --base-lr $BASE_LR \
    --lr-batches $LR_BATCHES \
    --lr-epochs $LR_EPOCHS \
    --ref-duration $REF_DURATION \
    --context-size $CONTEXT_SIZE \
    --prune-range $PRUNE_RANGE \
    --lm-scale $LM_SCALE \
    --am-scale $AM_SCALE \
    --simple-loss-scale $SIMPLE_LOSS_SCALE \
    --ctc-loss-scale $CTC_LOSS_SCALE \
    --print-diagnostics $PRINT_DIAGNOSTICS \
    --inf-check $INF_CHECK \
    --save-every-n $SAVE_EVERY_N \
    --keep-last-k $KEEP_LAST_K \
    --average-period $AVERAGE_PERIOD \
    --num-encoder-layers "$NUM_ENCODER_LAYERS" \
    --downsampling-factor "$DOWNSAMPLING_FACTOR" \
    --feedforward-dim "$FEEDFORWARD_DIM" \
    --num-heads "$NUM_HEADS" \
    --encoder-dim "$ENCODER_DIM" \
    --query-head-dim "$QUERY_HEAD_DIM" \
    --value-head-dim "$VALUE_HEAD_DIM" \
    --pos-head-dim "$POS_HEAD_DIM" \
    --pos-dim $POS_DIM \
    --encoder-unmasked-dim "$ENCODER_UNMASKED_DIM" \
    --cnn-module-kernel "$CNN_MODULE_KERNEL" \
    --decoder-dim $DECODER_DIM \
    --joiner-dim $JOINER_DIM \
    --chunk-size "$CHUNK_SIZE" \
    --left-context-frames "$LEFT_CONTEXT_FRAMES" \
    --use-transducer $USE_TRANSDUCER \
    --use-ctc $USE_CTC \
    --bucketing-sampler $BUCKETING_SAMPLER\
    --num-buckets $NUM_BUCKETS \
    --concatenate-cuts $CONCATENATE_CUTS \
    --duration-factor $DURATION_FACTOR \
    --gap $GAP \
    --on-the-fly-feats $ON_THE_FLY_FEATS \
    --shuffle $SHUFFLE \
    --drop-last $DROP_LAST \
    --return-cuts $RETURN_CUTS \
    --num-workers $NUM_WORKERS \
    --enable-spec-aug $ENABLE_SPEC_AUG \
    --spec-aug-time-warp-factor $SPEC_AUG_TIME_WARP_FACTOR \
    --enable-musan $ENABLE_MUSAN \
    --input-strategy "$INPUT_STRATEGY" \
    --use-mux ${USE_MUX} \
    --init-modules "encoder" \

