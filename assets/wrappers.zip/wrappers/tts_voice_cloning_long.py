import os
import random
import wave
from tqdm import tqdm
from TTS.api import TTS

# --- Configuration ---
TEXT_FILE = "/mnt/amtmpvf2/sangeet/data/MED/med_text_norm.txt"
SPEAKER_DIR = "/mnt/ac3/German/CommonVoice/cv-corpus-12.0-2022-12-07/de/clips/"
OUTPUT_DIR = "/mnt/amtmpvf2/sangeet/data/TTS_augmented/sample_long"
LANGUAGE = "de"
MODEL_NAME = "tts_models/multilingual/multi-dataset/xtts_v2"
DURATION_LIMIT_HOURS = 30
SAMPLE_RATE = 22050  # XTTS default

# --- GPU setup ---
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

# --- Load model ---
tts = TTS(model_name=MODEL_NAME, gpu=True)

# --- Load input ---
with open(TEXT_FILE, "r", encoding="utf-8") as f:
    lines = [line.strip() for line in f if line.strip()]

# speaker_wavs = [os.path.join(SPEAKER_DIR, f) for f in os.listdir(SPEAKER_DIR) if f.endswith(".wav")]
# if not speaker_wavs:
#     raise ValueError("No .wav files found in speaker folder!")

os.makedirs(OUTPUT_DIR, exist_ok=True)

def get_wav_duration(path):
    with wave.open(path, 'r') as wf:
        frames = wf.getnframes()
        rate = wf.getframerate()
        return frames / float(rate)

total_duration_sec = 0.0
pbar = tqdm(total=len(lines), desc="Generating", dynamic_ncols=True)

for idx, text in enumerate(lines):
    if total_duration_sec >= DURATION_LIMIT_HOURS * 3600:
        break
    
    if len(text.split()) < 40:
        pbar.update(1)
        continue
    
    # speaker = random.choice(speaker_wavs)
    speaker = 'arzt_youtube.wav'
    base_name = f"utt_{idx:06}"
    wav_path = os.path.join(OUTPUT_DIR, base_name + ".wav")
    txt_path = os.path.join(OUTPUT_DIR, base_name + ".txt")

    try:
        tts.tts_to_file(
            text=text,
            speaker_wav=speaker,
            language=LANGUAGE,
            file_path=wav_path
        )
        with open(txt_path, "w", encoding="utf-8") as tf:
            tf.write(text)
        dur = get_wav_duration(wav_path)
        total_duration_sec += dur
        pbar.set_description(f"Generated {total_duration_sec/3600:.2f} hrs")
        pbar.update(1)

    except Exception as e:
        print(f"Error at line {idx}: {e}")
        continue

pbar.close()
print(f"\nDone: Total duration = {total_duration_sec / 3600:.2f} hours")