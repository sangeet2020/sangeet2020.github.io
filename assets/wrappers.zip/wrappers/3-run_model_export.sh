#!/bin/bash

set -eou pipefail

SEED=1200
EPOCH=15
CAUSAL=1
AVG=4
CHUNK_SIZE=32
LEFT_CONTEXT_FRAMES=128
USE_AVERAGED_MODEL=1

PREFIX=med_tts
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR
EXP_DIR=${ROOT}/expt/exp-causal-cr-ctc-ft/${PREFIX}/${SEED}
BPE_MODEL=${EXP_DIR}/tokenizer/bpe.model
TOKENS=${EXP_DIR}/tokenizer/tokens.txt
ZIPFORMER_PATH=${ROOT}/zipformer

USE_CR_CTC=1
USE_CTC=1
USE_TRANSDUCER=1
USE_ATTENTION_DECODER=0

## Step-1: Export to torchscript model using torch.jit.script()
${ZIPFORMER_PATH}/export.py \
    --exp-dir ${EXP_DIR} \
    --causal ${CAUSAL} \
    --epoch ${EPOCH} \
    --avg  ${AVG} \
    --chunk-size ${CHUNK_SIZE} \
    --left-context-frames ${LEFT_CONTEXT_FRAMES} \
    --tokens ${TOKENS} \
    --jit 1 \
    --use-cr-ctc ${USE_CR_CTC} \
    --use-ctc ${USE_CTC} \
    --use-transducer ${USE_TRANSDUCER} \
    --use-attention-decoder ${USE_ATTENTION_DECODER} \

# It will generate a file `jit_script_chunk_16_left_128.pt` in the given `exp_dir`.
# You can later load it by `torch.jit.load("jit_script_chunk_16_left_128.pt")`.

# Check ./jit_pretrained_streaming.py for its usage.
# -------------------------------------------------------

## Step-2: Export `model.state_dict()`
${ZIPFORMER_PATH}/export.py \
    --exp-dir ${EXP_DIR} \
    --causal ${CAUSAL} \
    --epoch ${EPOCH} \
    --avg  ${AVG} \
    --chunk-size ${CHUNK_SIZE} \
    --left-context-frames ${LEFT_CONTEXT_FRAMES} \
    --tokens ${TOKENS} \
    --jit 0 \
    --use-cr-ctc ${USE_CR_CTC} \
    --use-ctc ${USE_CTC} \
    --use-transducer ${USE_TRANSDUCER} \
    --use-attention-decoder ${USE_ATTENTION_DECODER} \


# It will generate a file `pretrained.pt` in the given `exp_dir`. You can later
# load it by `icefall.checkpoint.load_checkpoint()`.
# -------------------------------------------------------

## Step-3: Export the model from PyTorch to ONNX

${ZIPFORMER_PATH}/export-onnx-streaming.py \
    --tokens ${TOKENS} \
    --use-averaged-model ${USE_AVERAGED_MODEL} \
    --epoch ${EPOCH} \
    --avg ${AVG} \
    --exp-dir ${EXP_DIR} \
    --causal ${CAUSAL} \
    --chunk-size ${CHUNK_SIZE} \
    --left-context-frames ${LEFT_CONTEXT_FRAMES}

# It will generate the following 3 files inside $repo/exp:

#   - encoder-epoch-99-avg-1-chunk-16-left-64.onnx
#   - decoder-epoch-99-avg-1-chunk-16-left-64.onnx
#   - joiner-epoch-99-avg-1-chunk-16-left-64.onnx

