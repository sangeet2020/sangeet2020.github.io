import os
import json
import logging
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Union, Sequence
from concurrent.futures import ProcessPoolExecutor
from contextlib import contextmanager
from tqdm import tqdm

import torchaudio
from lhotse import (
    Recording,
    RecordingSet,
    SupervisionSegment,
    SupervisionSet,
    validate_recordings_and_supervisions,
    fix_manifests,
)
from lhotse.utils import Pathlike
from lhotse.serialization import load_manifest
from lhotse import (
    get_ffmpeg_torchaudio_info_enabled,
    load_manifest,
    set_ffmpeg_torchaudio_info_enabled,
    validate_recordings_and_supervisions,
)
DATA_SPLITS = ("train", "valid", "test")


@contextmanager
def disable_ffmpeg_torchaudio_info() -> None:
    enabled = get_ffmpeg_torchaudio_info_enabled()
    set_ffmpeg_torchaudio_info_enabled(False)
    try:
        yield
    finally:
        set_ffmpeg_torchaudio_info_enabled(enabled)


def get_audio_duration(file_path: str) -> float:
    waveform, sample_rate = torchaudio.load(file_path)
    return waveform.shape[1] / sample_rate


def _parse_utterance(segment_id: str, audio_path: str, words: str) -> Optional[Tuple[Recording, SupervisionSegment]]:
    duration = get_audio_duration(audio_path)
    recording = Recording.from_file(audio_path, recording_id=segment_id)
    segment = SupervisionSegment(
        id=segment_id,
        recording_id=segment_id,
        duration=duration,
        start=0,
        channel=0,
        speaker="",
        text=words,
    )
    return recording, segment


def _prepare_part(part: str, records: List[Dict], num_jobs: int = 1) -> Tuple[RecordingSet, SupervisionSet]:
    with disable_ffmpeg_torchaudio_info():
        with ProcessPoolExecutor(max_workers=num_jobs) as ex:
            futures = []
            recordings = []
            supervisions = []
            for record in tqdm(records, desc=f"Distributing {part} tasks"):
                futures.append(ex.submit(
                    _parse_utterance,
                    segment_id=record["id"],
                    audio_path=record["audio_filepath"],
                    words=record["text"]
                ))

            for future in tqdm(futures, desc=f"Processing {part}"):
                result = future.result()
                if result is None:
                    continue
                recording, segment = result
                recordings.append(recording)
                supervisions.append(segment)

            recording_set = RecordingSet.from_recordings(recordings)
            supervision_set = SupervisionSet.from_segments(supervisions)
            # import pdb; pdb.set_trace()
            recording_set, supervision_set = fix_manifests(recording_set, supervision_set)
            validate_recordings_and_supervisions(recording_set, supervision_set)

            return recording_set, supervision_set


def read_evalwp_records(corpus_dir: Path) -> List[Dict]:
    records = []
    # import pdb; pdb.set_trace()
    for wav_path in sorted(corpus_dir.glob("*.wav")):
        txt_path = wav_path.with_suffix(".txt")
        if not txt_path.exists():
            continue
        with open(txt_path, "r", encoding="utf-8") as f:
            text = f.read().strip()
        duration = get_audio_duration(str(wav_path))
        records.append({
            "id": wav_path.stem,
            "audio_filepath": str(wav_path),
            "text": text,
            "duration": duration
        })
    return records


def prepare_evalwp(
    corpus_dir: Pathlike,
    output_dir: Pathlike,
    splits: Union[str, Sequence[str]] = ("train", "valid", "test"),
    num_jobs: int = 1,
) -> Dict[str, Dict[str, Union[RecordingSet, SupervisionSet]]]:
    corpus_dir = Path(corpus_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    manifests = {}

    for split in splits:
        print("Processing: ", split)
        split_dir =  corpus_dir / split
        records = read_evalwp_records(split_dir)
        recording_set, supervision_set = _prepare_part(split, records, num_jobs)

        recording_set.to_file(output_dir / f"tse_recordings_{split}.jsonl.gz")
        supervision_set.to_file(output_dir / f"tse_supervisions_{split}.jsonl.gz")

        manifests[split] = {
            "recordings": recording_set,
            "supervisions": supervision_set
        }

    return manifests


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("corpus_dir", type=str, help="Path to dataset with .wav and .txt files")
    parser.add_argument("output_dir", type=str, help="Path to save manifests")
    parser.add_argument("--splits", nargs="+", default=["test", "train", "valid"], help="Splits to process (e.g., train valid test)")
    parser.add_argument("--num_jobs", type=int, default=1, help="Number of parallel jobs")

    args = parser.parse_args()

    prepare_evalwp(
        corpus_dir=args.corpus_dir,
        output_dir=args.output_dir,
        splits=args.splits,
        num_jobs=args.num_jobs,
    )