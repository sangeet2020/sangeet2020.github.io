import os
import random
import wave
from tqdm import tqdm
from TTS.api import TTS
import argparse

# --- Configuration ---
# TEXT_FILE = "/mnt/amtmpvf2/sangeet/data/MED/med_text_norm.txt"
# OUTPUT_DIR = "/mnt/amtmpvf2/sangeet/data/TTS_augmented/sample_short"

SPEAKER_DIR = "/mnt/ac3/German/CommonVoice/cv-corpus-12.0-2022-12-07/de/clips/"
LANGUAGE = "de"
MODEL_NAME = "tts_models/multilingual/multi-dataset/xtts_v2"
SAMPLE_RATE = 22050  # XTTS default

def get_args():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--gpu-id",
        type=int,
        default=0,
        help="""Specify the GPU id to be used by CUDA_VISIBLE_DEVICES""",
    )

    parser.add_argument(
        "--input-file",
        type=str,
        help="""Text file for which audio files will be generated using TTS""",
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        help="""Output dir where generated data is to be saved""",
    )
    
    parser.add_argument(
        "--total-duration",
        type=int,
        help="""Total duration of the TTS data to be generated""",
    )

    return parser.parse_args()

def main():
    args = get_args()
    
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu_id)
    duration_limit_hours = args.total_duration
    
    # Load the TTS model
    tts = TTS(model_name=MODEL_NAME, gpu=True)

    # Load input text file
    with open(args.input_file, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]

    speaker_wavs = [os.path.join(SPEAKER_DIR, f) for f in os.listdir(SPEAKER_DIR) if f.endswith(".wav")]
    if not speaker_wavs:
        raise ValueError("No .wav files found in speaker folder!")

    os.makedirs(args.output_dir, exist_ok=True)

    def get_wav_duration(path):
        with wave.open(path, 'r') as wf:
            frames = wf.getnframes()
            rate = wf.getframerate()
            return frames / float(rate)

    total_duration_sec = 0.0
    pbar = tqdm(total=len(lines), desc="Generating", dynamic_ncols=True)

    for idx, text in enumerate(lines):
        if total_duration_sec >= duration_limit_hours * 3600:
            break
        
        if len(list(text)) > 150:
            pbar.update(1)
            continue
        
        speaker = random.choice(speaker_wavs)
        # speaker = 'arzt_youtube.wav'
        dir_prefix = str(args.input_file.split("_")[-1])
        base_name = f"utt_{dir_prefix}_{idx:06}"
        wav_path = os.path.join(args.output_dir, base_name + ".wav")
        txt_path = os.path.join(args.output_dir, base_name + ".txt")

        try:
            tts.tts_to_file(
                text=text,
                speaker_wav=speaker,
                language=LANGUAGE,
                file_path=wav_path
            )
            with open(txt_path, "w", encoding="utf-8") as tf:
                tf.write(text)
            dur = get_wav_duration(wav_path)
            total_duration_sec += dur
            pbar.set_description(f"Generated {total_duration_sec/3600:.2f} hrs")
            pbar.update(1)

        except Exception as e:
            print(f"Error at line {idx}: {e}")
            continue

    pbar.close()
    print(f"\nDone: Total duration = {total_duration_sec / 3600:.2f} hours")
    
if __name__ == "__main__":
    main()