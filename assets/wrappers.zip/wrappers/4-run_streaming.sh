#!/usr/bin/env bash

set -eou pipefail

stage=-1
stop_stage=100
. ../shared/parse_options.sh || exit 1

# Model path
ROOT_DIR=/mnt/amtmpvf2/sangeet/backup
MODEL_DIR="Zipformer-CR-CTC-deu16/icefall/zipformer/deu16-causal-model-medium-66M-params/"

ENCODER_MODEL="${ROOT_DIR}/${MODEL_DIR}/encoder-epoch-30-avg-8-chunk-32-left-128.onnx"
DECODER_MODEL="${ROOT_DIR}/${MODEL_DIR}/decoder-epoch-30-avg-8-chunk-32-left-128.onnx"
JOINER_MODEL="${ROOT_DIR}/${MODEL_DIR}/joiner-epoch-30-avg-8-chunk-32-left-128.onnx"
TOKENS=${ROOT_DIR}/${MODEL_DIR}/tokenizer/tokens.txt

# LM Params
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/Eng16
LM_MODEL=${ROOT}/LM/my-rnnlm-exp/1200/with-state-epoch-19-avg-2.onnx
LODR_FST=${ROOT}/ASR/data/Multi_dataset/all_data/lm/G_2_gram.fst.txt
LODR_SCALE=-0.5

WAV_FILE="/mnt/ac/broadcast16/audio/Heute_100_Sekunden/2009/02/02/20090202.16.49_Heute_100_Sekunden.wav"  # DE
# WAV_FILE="/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/Eng16/ASR/obsolete/Josh-Kaufman-TedTalk.wav"  # EN

# sherpa-onnx build dir
SHERPA_DIR=/mnt/local/sangeet/workncode/k2-fsa/sherpa-onnx


log() {
  # This function is from espnet
  local fname=${BASH_SOURCE[1]##*/}
  echo -e "\n$(date '+%Y-%m-%d %H:%M:%S') (${fname}:${BASH_LINENO[0]}:${FUNCNAME[1]}) $* ********"
}

if [ $stage -le 0 ] && [ $stop_stage -ge 0 ]; then
  log "Stage 0: Decoding using built binary: sherpa-onnx/build/bin/sherpa-onnx"
  ${SHERPA_DIR}/build/bin/sherpa-onnx \
    --model-type="zipformer2" \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL} \
    --tokens=${TOKENS} \
    ${WAV_FILE}
fi

if [ $stage -le 1 ] && [ $stop_stage -ge 1 ]; then
  log "Stage 1: Decoding using python script (sherpa-onnx not reqd)"
  ./zipformer_sds/onnx_pretrained-streaming.py \
    --encoder-model-filename ${ENCODER_MODEL} \
    --decoder-model-filename ${DECODER_MODEL} \
    --joiner-model-filename ${JOINER_MODEL} \
    --tokens ${TOKENS} \
    ${WAV_FILE}
fi

## Python API- Offline decoding using Sherpa
if [ $stage -le 2 ] && [ $stop_stage -ge 2 ]; then
  log "Stage 2: Sherpa-onnx Python API- Transcribe file(s) with a streaming model."
  python ${SHERPA_DIR}/python-api-examples/offline-decode-files.py \
    --tokens=${TOKENS} \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL} \
    --debug=true \
    ${WAV_FILE}
fi

## Python API- Offline decoding using Sherpa
if [ $stage -le 3 ] && [ $stop_stage -ge 3 ]; then
  log "Stage 2: Sherpa-onnx Python API- Transcribe file(s) with a streaming model + LM."
  python ${SHERPA_DIR}/python-api-examples/online-decode-files.py \
    --tokens=${TOKENS} \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL} \
    --decoding-method="modified_beam_search" \
    --lm=${LM_MODEL} \
    ${WAV_FILE}
fi

if [ $stage -le 4 ] && [ $stop_stage -ge 4 ]; then
  log "Stage 3: Sherpa-onnx Python API- Real-time speech recognition from a microphone (with endpoint detection)"
  python ${SHERPA_DIR}/python-api-examples/speech-recognition-from-microphone-with-endpoint-detection.py \
    --tokens=${TOKENS} \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL}
fi

if [ $stage -le 5 ] && [ $stop_stage -ge 5 ]; then
  log "Stage 3: Sherpa-onnx Python API- Streaming WebSocket Server"
  PORT=6060
  echo -e "Starting the server at port ${PORT} ..."
  echo -e "In another terminal window run the command below and speak OR open http://localhost:${PORT}/ and speak from the browser"
  echo -e "python3 ${SHERPA_DIR}/python-api-examples/online-websocket-client-microphone.py --server-addr localhost --server-port ${PORT}"
  
  python ${SHERPA_DIR}/python-api-examples/streaming_server.py \
    --tokens=${TOKENS} \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL} \
    --doc-root=${SHERPA_DIR}/python-api-examples/web \
    --port ${PORT}
fi

# /mnt/local/sangeet/workncode/k2-fsa/fang/sherpa-onnx/build/bin/sherpa-onnx-online-websocket-server \
#   --encoder=${ENCODER_MODEL} \
#   --decoder=${DECODER_MODEL} \
#   --joiner=${JOINER_MODEL} \
#   --tokens=${TOKENS} \
#   --log-file=./log.txt \
#   --max-batch-size=5 \
#   --loop-interval-ms=10 \
#   --port=6006  \
#   --num-work-threads=3 \
#   --num-io-threads=2

if [ $stage -le 6 ] && [ $stop_stage -ge 6 ]; then
  log "Stage 6: Decoding using built binary + LM [online LM rescore]"
  ${SHERPA_DIR}/build/bin/sherpa-onnx  \
    --model-type="zipformer2" \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL} \
    --tokens=${TOKENS} \
    --lm=${LM_MODEL} \
    --lodr-fst=${LODR_FST} \
    --lodr-scale=${LODR_SCALE} \
    ${WAV_FILE}
fi

if [ $stage -le 7 ] && [ $stop_stage -ge 7 ]; then
  log "Stage 7: Decoding using built binary + LM [online LM shallow fusion]"
  ${SHERPA_DIR}/build/bin/sherpa-onnx  \
    --model-type="zipformer2" \
    --encoder=${ENCODER_MODEL} \
    --decoder=${DECODER_MODEL} \
    --joiner=${JOINER_MODEL} \
    --tokens=${TOKENS} \
    --lm=${LM_MODEL} \
    --lodr-fst=${LODR_FST} \
    --lodr-scale=${LODR_SCALE} \
    --lodr-backoff-id=500 \
    --lm-shallow-fusion=true \
    ${WAV_FILE}
fi