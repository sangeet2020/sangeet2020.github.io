#!/bin/bash

# MODEL: zipformer + pruned-transducer w/ CR-CTC

export CUDA_VISIBLE_DEVICES="0,1,2,3"
## --causal 1 is for streaming ASR training

SEED=1200
WORLD_SIZE=4
NUM_EPOCHS=30
START_EPOCH=1
USE_FP16=1
CAUSAL=1

PREFIX=de_meeting  #ukostt
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR
BPE_MODEL=${ROOT}/data/${PREFIX}/${SET}/lang_bpe_500/bpe.model
MANIFEST_DIR=${ROOT}/data/${PREFIX}/${SET}/fbank/

MAX_DURATION=300
EXP_DIR=${ROOT}/expt/exp-causal-cr-ctc-de-meeting/${PREFIX}/${SEED}
MASTER_PORT=12345
START_BATCH=0
BASE_LR=0.045
ENABLE_MUSAN=False
ZIPFORMER_PATH=${ROOT}/zipformer

# CR-CTC Specific Params
USE_CR_CTC=1
USE_CTC=1
USE_TRANSDUCER=1
USE_ATTENTION_DECODER=0
ENABLE_SPEC_AUG=False
CTC_LOSS_SCALE=0.1
CR_LOSS_SCALE=0.02
TIME_MASK_RATIO=2.5

mkdir -p ${EXP_DIR}
cp "$0" ${EXP_DIR}

python ${ZIPFORMER_PATH}/train.py \
   --prefix ${PREFIX} \
   --seed ${SEED} \
   --world-size $WORLD_SIZE \
   --exp-dir ${EXP_DIR} \
   --num-epochs $NUM_EPOCHS \
   --start-epoch $START_EPOCH \
   --use-fp16 $USE_FP16 \
   --causal $CAUSAL \
   --bpe-model "$BPE_MODEL" \
   --manifest-dir "$MANIFEST_DIR" \
   --max-duration $MAX_DURATION \
   --master-port $MASTER_PORT \
   --start-batch $START_BATCH \
   --base-lr $BASE_LR \
   --enable-musan $ENABLE_MUSAN \
   --use-cr-ctc ${USE_CR_CTC} \
   --use-ctc ${USE_CTC} \
   --use-transducer ${USE_TRANSDUCER} \
   --use-attention-decoder ${USE_ATTENTION_DECODER} \
   --enable-spec-aug $ENABLE_SPEC_AUG \
   --ctc-loss-scale ${CTC_LOSS_SCALE} \
   --cr-loss-scale ${CR_LOSS_SCALE} \
   --time-mask-ratio ${TIME_MASK_RATIO} \

   
