#!/bin/bash

export CUDA_VISIBLE_DEVICES="2,3"
## --causal 1 is for streaming ASR training

SEED=1200
WORLD_SIZE=2
NUM_EPOCHS=30
START_EPOCH=1
USE_FP16=1
CAUSAL=1
DO_FINETUNE=1

PREFIX=be_commonvoice  #ukostt
SET=all_data
ROOT=/mnt/local/sangeet/workncode/k2-fsa/icefall/egs/UkOSTT/ASR
MANIFEST_DIR=${ROOT}/data/${PREFIX}/${SET}/fbank/

PRETRAINED_PATH=${ROOT}/expt/exp-causal/combined/1200
FINETUNE_CKPT=${PRETRAINED_PATH}/pretrained.pt
BPE_MODEL=${PRETRAINED_PATH}/tokenizer/bpe.model

MAX_DURATION=500
EXP_DIR=${ROOT}/expt/exp-causal-ft/${PREFIX}/${SEED}
MASTER_PORT=12345
START_BATCH=0
BASE_LR=0.0045
ENABLE_SPEC_AUG=True
ENABLE_MUSAN=True
ZIPFORMER_PATH=${ROOT}/zipformer

mkdir -p ${EXP_DIR}
cp "$0" ${EXP_DIR}

python ${ZIPFORMER_PATH}/finetune.py \
   --prefix ${PREFIX} \
   --seed ${SEED} \
   --world-size $WORLD_SIZE \
   --finetune-ckpt ${FINETUNE_CKPT} \
   --do-finetune ${DO_FINETUNE} \
   --exp-dir ${EXP_DIR} \
   --num-epochs $NUM_EPOCHS \
   --start-epoch $START_EPOCH \
   --use-fp16 $USE_FP16 \
   --causal $CAUSAL \
   --bpe-model "$BPE_MODEL" \
   --manifest-dir "$MANIFEST_DIR" \
   --max-duration $MAX_DURATION \
   --master-port $MASTER_PORT \
   --start-batch $START_BATCH \
   --base-lr $BASE_LR \
   --enable-spec-aug $ENABLE_SPEC_AUG \
   --enable-musan $ENABLE_MUSAN \
   
